import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: 'Navigation Basics',
    home: FirstRoute(),
  ));
}

final myController = TextEditingController();
final myController1 = TextEditingController();

class FirstRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Login Page'),
        ),
      body: Center(
        child: Column(
          children: <Widget>[

            Container(
              width: 300,
              child: TextField(
                maxLength: 15,
                decoration: InputDecoration(
                  hintText: 'username',
                ),
                controller: myController,
              ),
            ),
            Container(
              width: 300,
              child: TextField(
                maxLength: 20,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'password',
                ),
                controller: myController1,
              ),
            ),
            ElevatedButton(
              child: Text('log in'),
              onPressed: () {
                if(myController.text == "Big Smoke" && myController1.text == "2number9s"){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SecondRoute(new Key("SecondPage"), myController.text, 1)),
                  );
                } else {}
              },
            ),
          ]
        ),
      )
    );
  }
}

class SecondRoute extends StatelessWidget {
  String User = "";
  String auxText = "";
  int i = 0;
  final camelCalculatorTextController = TextEditingController();
  final camelCalculatorTextController1 = TextEditingController();
  final camelCalculatorTextController2 = TextEditingController();
  String action = "";
  SecondRoute(Key key, @required this.User, @required this.i) : super(key:key);

  @override
  Widget build (BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Quick Maths"),

      ),
      body: Center(
        child: Column(
          children: <Widget>[
            Container(
              width: 300,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text("Welcome " + this.User),
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 55,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextField(
                      //maxLength: 10,
                      textAlign: TextAlign.center,
                      controller: camelCalculatorTextController,
                    ),
                  ),

                ),
                Container(
                  width: 45,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextField(
                      //maxLength: 10,
                      textAlign: TextAlign.center,
                      controller: camelCalculatorTextController1,
                    ),
                  ),
                ),
                Container(
                  width: 55,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: TextField(
                      //maxLength: 10,
                      textAlign: TextAlign.center,
                      controller: camelCalculatorTextController2,
                    ),
                  ),
                ),
              ]
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "7";
                    else camelCalculatorTextController2.text = "7";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('7'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "8";
                    else camelCalculatorTextController2.text = "8";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('8'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "9";
                    else camelCalculatorTextController2.text = "9";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('9'),
                ),
                ElevatedButton(
                  onPressed: () {
                    camelCalculatorTextController1.text = "÷";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.black26,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('÷'),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "4";
                    else camelCalculatorTextController2.text = "4";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('4'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "5";
                    else camelCalculatorTextController2.text = "5";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('5'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "6";
                    else camelCalculatorTextController2.text = "6";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('6'),
                ),
                ElevatedButton(
                  onPressed: () {
                    camelCalculatorTextController1.text = "×";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.black26,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('×'),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "1";
                    else camelCalculatorTextController2.text = "1";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('1'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "2";
                    else camelCalculatorTextController2.text = "2";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('2'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "3";
                    else camelCalculatorTextController2.text = "3";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('3'),
                ),
                ElevatedButton(
                  onPressed: () {
                    camelCalculatorTextController1.text = "−";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.black26,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('−'),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  onPressed: () {
                    if(camelCalculatorTextController.text.length == 0)
                      camelCalculatorTextController.text = "0";
                    else camelCalculatorTextController2.text = "0";
                  },
                  child: Text('0'),
                ),

                ElevatedButton(
                  onPressed: () {
                    if(camelCalculatorTextController.text.length != 0 && camelCalculatorTextController2.text.length != 0)
                      switch(camelCalculatorTextController1.text) {
                        case "+":
                          { Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => ThirdRoute(double.parse(camelCalculatorTextController.text) + double.parse(camelCalculatorTextController2.text))),
                            );
                          } break;
                        case "−":
                          { Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => ThirdRoute(double.parse(camelCalculatorTextController.text) - double.parse(camelCalculatorTextController2.text))),
                            );
                          } break;
                        case "×":
                          { Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => ThirdRoute(double.parse(camelCalculatorTextController.text) * double.parse(camelCalculatorTextController2.text))),
                            );
                          } break;
                        case "÷":
                          { Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => ThirdRoute(double.parse(camelCalculatorTextController.text) / double.parse(camelCalculatorTextController2.text))),
                            );
                          } break;
                        default: break;
                      }
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.black26,
                      padding: EdgeInsets.symmetric(horizontal: 78, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('='),
                ),
                ElevatedButton(
                  onPressed: () {
                    camelCalculatorTextController1.text = "+";
                  },
                  style: ElevatedButton.styleFrom(
                      primary: Colors.black26,
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  child: Text('+'),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.redAccent,
                      padding: EdgeInsets.symmetric(horizontal: 125, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  onPressed: () {
                    camelCalculatorTextController.text = "";
                    camelCalculatorTextController1.text = "";
                    camelCalculatorTextController2.text = "";

                  },
                  child: Text('DELETE'),
                ),
              ],
            ),
          ],
        )
      ),
    );
  }
}

class ThirdRoute extends StatelessWidget {
  final double displayResult;
  final resultTextController = new TextEditingController();
  ThirdRoute(@required this.displayResult) {
    resultTextController.text = displayResult.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    appBar: AppBar(
      title: Text("Result"),
    ),
    body: Center(
      child: ListView(
        children: [
            /*Container(
              width: 300,
              child: TextField(
                controller: resultTextController,
              ),
            ),*/
            AlertDialog(
              title: Text("Result"),
              content: Text(displayResult.toString()),
                // controller: resultTextController,
              actions: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.grey,
                      padding: EdgeInsets.symmetric(horizontal: 65, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ForthRoute()),
                      );
                  },
                  child: Text('Ok'),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.grey,
                      padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                      textStyle: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold)),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Back'),
                ),
              ],
              elevation: 24.0,
              backgroundColor: Colors.tealAccent,

            ),
          ],

        )
      ),
    );
  }
}

class ForthRoute extends StatelessWidget {
  final resultTextController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Result"),
      ),
      body: Container(
        margin: EdgeInsets.symmetric(vertical: 20.0),
        height: 500.0,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: <Widget>[
            Container(
              width: 500.0,
              color: Colors.red,
            ),
            Container(
              width: 500.0,
              color: Colors.blue,
            ),
            Container(
              width: 500.0,
              color: Colors.green,
            ),
            Container(
              width: 500.0,
              color: Colors.yellow,
            ),
            Container(
              width: 500.0,
              color: Colors.orange,
            ),
          ],
        ),
      ),
    );
  }
}
